# Daymark — Milestone 1 (Foundation)

Native Android (Kotlin, Jetpack Compose, Material 3, MVVM, Room). Offline-only, no network, no permissions, no AI.

## STATUS: written but NOT yet compiled or run
This source was authored in an environment with no Android SDK and no access to Google's Maven repository,
so it has **never been built, tested, or installed**. Expect a few first-build fixes. Treat nothing as verified
until you have done the steps below.

## Build
1. Install Android Studio (current stable) — it bundles the JDK and Android SDK.
2. File > Open > this folder. Let Gradle sync. If prompted, accept SDK 35 install and the Gradle version AGP asks for
   (AGP 8.7.x needs Gradle 8.9+). Android Studio creates the Gradle wrapper for you.
3. Versions in `gradle/libs.versions.toml` were chosen from memory — upgrade to current stable if sync complains.
4. Run unit tests: `./gradlew :app:testDebugUnitTest` (6 tests in `ActivityRulesTest`).
5. Install on your phone: enable Developer options + USB debugging, connect, press Run. Or `./gradlew :app:installDebug`.

## Implemented in this milestone (pending your verification)
- 5-tab bottom navigation + Settings icon; light/dark follows system.
- Room database v1 (tasks, activities, categories); default categories seeded once.
- Today: add task (title + optional estimate), complete/uncomplete, delete with confirmation, progress, tracked-time total.
- Timeline: log activity (HH:mm start/end), overlap warning without altering other records, delete with Undo.
- Settings: real "Delete all data", privacy statement, version.

## Not implemented (shown as such in the app)
Screen Time, Goals, Insights, categories UI/classification, edit/split/merge, ideas/goals capture, reminders,
DataStore theme override, encryption/Keystore, app lock, export, backup, midnight date rollover,
ranges crossing midnight, on-device UI tests, release signing/minification.

## Costs
None: no backend, no accounts. Google Play publishing later has a one-time developer registration fee (check current amount).
